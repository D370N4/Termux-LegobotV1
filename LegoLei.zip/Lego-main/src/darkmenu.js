const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Bot:*

➸ *${prefix}bilada*
➸ *${prefix}grupo*
➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}boanoite1*
➸ *${prefix}bomdia1*
➸ *${prefix}boatarde1*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*

╔════════════════════
  Bot do Legosi-dono
  DUVIDAS? 👇
  wa.me/18482765528
╚════════════════════`
}

exports.darkmenu = darkmenu





