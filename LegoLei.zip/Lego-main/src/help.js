const help = (prefix) => {
	return `

╔════════════════════
║        🌹LegoBot V1🌹
╠════════════════════


➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online 」*

       • ──── ✾ ──── •
       *FIGURINHAS*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda\n
➸ Comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ uso : responder imagem ou enviar imagem com legenda/n
➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta\n

       • ─── ✾ ─── •
       *MEMES*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}meme*
➸ útil em : mandar imagens aleatórias de meme [inglês]
➸ uso : basta emviar o comando\n

       • ──── ✾ ──── •
       *OUTROS...*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}loli*
➸ útil em : gerar uma loli aleatória a cada uso do comando
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}bilada*
➸ útil em : veja aquela vadia tendo sua cara acertada por uma bela bilada
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}grupo*
➸ útil em : apoia o criador do bot e  ganha um belo grupo de hentai  de brinde:D
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}nsfwloli*
➸ útil em : mandar imagem de nsfw loli
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}wait*
➸ útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ uso : responder imagem ou enviar imagem com legenda\n
➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot\n

       • ─── ✾ ─── •
       *GRUPO*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}marcar*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}add*
➸ útil em : adicionar membro ao grupo
➸ uso : *${prefix}add 5585xxxxx*\n
➸ Nota : o bot precisa ser admin!\n
➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

       • ────── ✾ ────── •
       *MENU DO LegoBot*【✔】
       • ────── ✾ ────── •              

➸ *${prefix}help1* ♔
    

╔════════════════════
  FEITO POR *Legosi-dono*
  DUVIDAS? 👇
  wa.me/18482765528
╚════════════════════`
}

exports.help = help